/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cakesolutioncorrectversion;

/**
 *
 * @author anders
 */
public class Cake implements GameObject{

    @Override
    public boolean canBeTaken() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Location getLocation() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean setLocation(Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
