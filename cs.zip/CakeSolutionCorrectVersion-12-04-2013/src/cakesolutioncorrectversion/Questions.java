/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cakesolutioncorrectversion;

/**
 *
 * @author eskandarpahlavaafshari
 */
public class Questions {
    
    String question;
    String correctAnswer;
    String answer1;
    String answer2;
    String answer3;
    
    public static void answerQuestion(){
        
//   
//        
//        Scanner userInput = new Scanner(System.in);
//        
//        while(//Vores player rammer de rigtige koordinater){
//                System.out.println("Hurray you reache a cake and will now get a quistion to answer");
//                System.out.println("VI KALDER QUESTION HER");
//                System.out.println("Type in your answer");
//                String questionAnswer = userInput.nextLine();
//                if (answers[] = questionsAnswer){
//                    System.out.println("Hurray! Your answer was right");
//                }
//                else{
//                    System.out.prinln("Sorry wrong answer. Move on!");
//                }
                        
//                }
    
                }
    
    
}
