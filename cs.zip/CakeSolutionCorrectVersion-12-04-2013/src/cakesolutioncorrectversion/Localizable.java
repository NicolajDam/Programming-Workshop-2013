/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cakesolutioncorrectversion;

import cakesolutioncorrectversion.Location;
/**
 *
 * @author anders
 */
public interface Localizable {
    
    /**Returns the current location*/
    Location getLocation();
    
    /**Sets the location*/
    boolean setLocation(Location location);
    
    
    
    
}
