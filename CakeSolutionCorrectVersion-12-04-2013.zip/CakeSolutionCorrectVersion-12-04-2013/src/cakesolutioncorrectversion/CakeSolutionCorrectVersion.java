/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cakesolutioncorrectversion;

import cakesolutioncorrectversion.Location.Direction;
import java.util.List;

/**
 *
 * @author nicolajdamfrederiksen
 */
public class CakeSolutionCorrectVersion {

    
    
    
    public void startGame(){
    
    
            // Create worlds 
            Cakistan world1 = new Cakistan();
        
        
            // Create player 
    
    
    
    
    
    
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  
        
        
        CakeSolutionCorrectVersion game = new CakeSolutionCorrectVersion();
        game.startGame();
        
        /*Cakistan newWorld = new Cakistan();
                List<Location> myLocations = newWorld.getLocations();
                
                /**This for loop gets the locations and prints out 
                 * the description of these */
                
//                for (Location L : myLocations) { 
//                        System.out.println("Fancy for loop: " 
//                                +L.getDescription());
//                }
//                
//                /**This for loop gets the directions and prints out them out */
//                
//                for (Direction theNextDirection : Direction.values()) {
//                        System.out.println(theNextDirection);
//                    
//                }
//        
        
    }
}
