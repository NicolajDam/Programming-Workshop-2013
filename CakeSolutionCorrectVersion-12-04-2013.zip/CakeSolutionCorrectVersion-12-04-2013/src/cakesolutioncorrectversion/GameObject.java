/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cakesolutioncorrectversion;

/**
 *
 * @author anders
 */
public interface GameObject extends Localizable {
    
    boolean canBeTaken();
    
}
